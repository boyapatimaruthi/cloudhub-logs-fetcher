package message.transformers.models;

import java.io.Serializable;
import java.util.List;

public class Application implements Serializable {
	/**
	 * 
	 */


	private String createTime;
	private String deploymentId;
	private String endTime;
	private List<Instance> instances;
	private String startTime;

	private static final long serialVersionUID = 647975410613978748L;
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getDeploymentId() {
		return deploymentId;
	}
	public void setDeploymentId(String deploymentId) {
		this.deploymentId = deploymentId;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public List<Instance> getInstances() {
		return instances;
	}
	public void setInstances(List<Instance> instances) {
		this.instances = instances;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	@Override
	public String toString() {
		return "Application [createTime=" + createTime + ", deploymentId=" + deploymentId + ", endTime=" + endTime
				+ ", instances=" + instances + ", startTime=" + startTime + "]";
	}


}
