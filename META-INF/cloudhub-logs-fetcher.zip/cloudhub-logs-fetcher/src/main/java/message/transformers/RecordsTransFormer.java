package message.transformers;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import message.transformers.models.Application;
import message.transformers.models.Instance;
import message.transformers.models.Records;

public class RecordsTransFormer extends AbstractMessageTransformer {

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		// TODO Auto-generated method stub
		Records records =(Records) message.getPayload();
		//System.out.println(message.getPayload());

		List<Instance> instances = new ArrayList<Instance>();
		for(Application a : records.getData()){
			instances.addAll(a.getInstances());
		}
		instances = instances.stream().filter(i -> "STARTED".equalsIgnoreCase(i.getStatus())).collect(Collectors.toList());

		return instances;
	}

}
