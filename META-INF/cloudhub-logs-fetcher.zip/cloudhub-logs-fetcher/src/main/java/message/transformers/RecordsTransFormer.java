package message.transformers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import message.transformers.models.Application;
import message.transformers.models.Instance;
import message.transformers.models.Records;

public class RecordsTransFormer extends AbstractMessageTransformer {

	private String allowedAppInstancesWithStatus;
	private String [] allowedStatuses ={"STARTED"} ;
	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		
		Records records =(Records) message.getPayload();
		//System.out.println(message.getPayload());
		//System.out.println(allowedAppInstancesWithStatus);
		
		if(null != allowedAppInstancesWithStatus && !allowedAppInstancesWithStatus.isEmpty() && allowedAppInstancesWithStatus.contains(",")){
			allowedStatuses = allowedAppInstancesWithStatus.split(",");
			//Expected STARTED,TERMINATED
		}
		allowedStatuses = trimElements(allowedStatuses);
		List<Instance> instances = new ArrayList<Instance>();
		for(Application a : records.getData()){
			instances.addAll(a.getInstances());
		}
		instances = instances.stream().filter(i -> Arrays.asList(allowedStatuses).contains(i.getStatus())).collect(Collectors.toList());

		return instances;
	}

	public String getAllowedAppInstancesWithStatus() {
		return allowedAppInstancesWithStatus;
	}

	public void setAllowedAppInstancesWithStatus(String allowedAppInstancesWithStatus) {
		this.allowedAppInstancesWithStatus = allowedAppInstancesWithStatus;
	}
	
	private String [] trimElements(String [] allowedStatus){
		for(int i=0; i< allowedStatuses.length;i++){
			allowedStatuses[i] = allowedStatuses[i].trim();
		}
		return allowedStatus;
	}

}
