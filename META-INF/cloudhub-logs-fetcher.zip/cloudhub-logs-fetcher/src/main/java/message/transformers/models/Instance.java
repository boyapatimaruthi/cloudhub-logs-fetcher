package message.transformers.models;

import java.io.Serializable;

public class Instance implements Serializable {

/**
	 * 
	 */
	private static final long serialVersionUID = -8284657008716995433L;
private String instanceId;
private String publicIPAddress;
private String region; 
private String status;
public String getInstanceId() {
	return instanceId;
}
public void setInstanceId(String instanceId) {
	this.instanceId = instanceId;
}
public String getPublicIPAddress() {
	return publicIPAddress;
}
public void setPublicIPAddress(String publicIPAddress) {
	this.publicIPAddress = publicIPAddress;
}
public String getRegion() {
	return region;
}
public void setRegion(String region) {
	this.region = region;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
@Override
public String toString() {
	return "Instance [instanceId=" + instanceId + ", publicIPAddress=" + publicIPAddress + ", region=" + region
			+ ", status=" + status + "]";
}

}
