package message.transformers.models;

import java.io.Serializable;
import java.util.List;

public class Records implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8544856036815179228L;
	/**
	 * 
	 */
	private List<Application> data;
	private Integer total;
	public List<Application> getData() {
		return data;
	}
	public void setData(List<Application> data) {
		this.data = data;
	}
	public Integer getTotal() {
		return total;
	}
	@Override
	public String toString() {
		return "Records [data=" + data + ", total=" + total + "]";
	}
	public void setTotal(Integer total) {
		this.total = total;
	}

}
